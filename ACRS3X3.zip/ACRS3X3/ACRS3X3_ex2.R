## Example 2: Using R for expediting Monte Carlo Analysis of GEMPACK-based CGE models

## Load the rgtap library:
library(rgtap)

ESUBM.FOOD <- 2.39*2
ESUBM.MNFCS <- 2.86*2
ESUBM.SVCS <- 1.95*2



##SERIAL SOLUTIONS:
mc.serial.time <- system.time(
mc.serial <- lapply( c(1:samples), function(i){
                                        #i <- 2
    ESUBM.FOOD.i <- rnorm(n =1, mean = ESUBM.FOOD, sd = 2)
    lines <- c(
        paste( '3 Real SpreadSheet Header "ESBD";' ),
        paste( ESUBM.FOOD.i/2),
        paste( ESUBM.MNFCS/2 ),
        paste( ESUBM.SVCS/2 ),
        paste( '3 Real SpreadSheet Header "ESBM";' ),
        paste( ESUBM.FOOD.i ),
        paste( ESUBM.MNFCS ),
        paste( ESUBM.SVCS ))
    writeLines(lines, con = paste('./results/sigma.', i, '.txt', sep ="") )
    system( paste('txt2har ./results/sigma.', i, '.txt ./results/sigma.', i,'.har', sep = "") )
    exp <- paste('gtap -cmf tmsfse_ex2.cmf -p1=', i, sep = "")
    system(exp, ignore.stdout = TRUE)
    ## Extract varaiables in map to a solution file:
    extractvar(solution.dir = "./results/",
            solution.name = paste("tmsfsem.",i, sep =""),
            var.map = "example1.map",
            solution.out = paste("./results/tmsfsem.",i,".sol", sep ="")
            )
    ## Read results: pm, qo, qxs(SSA, EU) and sigma:
    qo <- readsol( solution.dir = "./results/",
              solution.out = paste("tmsfsem.",i,".sol", sep =""),
              csv.out = "qo.csv",
              header = "0002" )
    pm <- readsol( solution.dir = "./results/",
              solution.out = paste("tmsfsem.",i,".sol", sep =""),
              csv.out = "pm.csv",
              header = "0001" )
    qxs <- readsol( solution.dir = "./results/",
              solution.out = paste("tmsfsem.",i,".sol", sep =""),
              csv.out = "qxs.csv",
              header = "0003" )
    sigma <- readsol( solution.dir = "./results/",
              solution.out = paste('sigma.', i, '.har', sep =""),
              csv.out = "sigma.csv",
              header = "ESBM" )
    list(qo = qo, pm = pm, qxs = qxs, sigma = sigma)
})
)
save(mc.serial.time, mc.serial, file = "./results/mc.serial.RData")

## ## cmbhar SEEMS TO HAVE A LIMIT AT 236 LINES!!
## ## Combine solution files:
## .ll <- c("",
##          samples,
##          paste("./results/tmsfsem.",c(1:samples),".sol", sep =""),
##          "./results/combined.results.har"
##          )
## writeLines( .ll, con = paste('./results/cmbhar.sti', sep ="") )
## system("cmbhar -STI ./results/cmbhar.sti")

## ## Combine sigma files:
## .ll <- c("",
##          samples,
##          paste("./results/sigma.",c(1:samples),".har", sep =""),
##          "./results/combined.sigma.har"
##          )
## writeLines( .ll, con = paste('./results/cmbhar.sti', sep ="") )
## system("cmbhar -STI ./results/cmbhar.sti")

## Remove files:

file.remove(
    paste("./results/", setdiff(list.files("./results"),
                                c("mc.serial.RData")), sep ="")
            )



## Read values for plots:
load("./results/mc.serial.RData")

sigma.food <-  sapply(mc.serial, function(i){
    d <- i[["sigma"]]
    d$Value[1]
})

qo.food.ssa <- sapply(mc.serial, function(i){
    d <- i[["qo"]]
    with(d, d$Value[ NSAV_COMM == "Food" & REG == "SSA"] )
})

pm.food.ssa <- sapply(mc.serial, function(i){
    d <- i[["pm"]]
    with(d, d$Value[ NSAV_COMM == "Food" & REG == "SSA"] )
})

qxs.food.ssa.eu <- sapply(mc.serial, function(i){
    d <- i[["qxs"]]
    with(d, d$Value[ TRAD_COMM == "Food" & REG == "SSA" & REG.1 == "EU" ] )
})

## Plots:
pdf( file = "ACRS3X3ex2.pdf", width = 6, height = 6)
par( mfrow = c(2,2) )
plot( density ( sigma.food ), main = "ESUBM(FOOD)", xlab = "Trade Elasticity" )
plot( density ( qo.food.ssa ), main = "qo(FOOD, SSA)", xlab ="% change"  )
plot( density ( pm.food.ssa ), main = "pm(FOOD, SSA)", xlab ="% change"  )
plot( density ( qxs.food.ssa.eu ), main = "qxs(FOOD, SSA, EU)", xlab ="% change"  )
dev.off()
