## Example 2: R for Serial Monte Carlo Experiments with the GTAP model

## Load the rgtap library:
library(rgtap)

## BLOCK 1 (In the Standard GTAP model ESUBM = 2*ESUBD, see
## header ESUBD in default.prm to verify original values):
ESUBM.FOOD <- 2.39*2
ESUBM.MNFCS <- 2.86*2
ESUBM.SVCS <- 1.95*2

N <- 10

## BLOCK 2: SERIAL SOLUTIONS:
mc.serial.time <- system.time(
    mc.serial <- lapply( c(1:N), function(i){
        ## BLOCK 2.1: Write sigma.<p1>.har
        ESUBM.FOOD.i <- rnorm(n =1, mean = ESUBM.FOOD, sd = 2)
        lines <- c(
        paste( '3 Real SpreadSheet Header "ESBD";' ),
        paste( ESUBM.FOOD.i/2),
        paste( ESUBM.MNFCS/2 ),
        paste( ESUBM.SVCS/2 ),
        paste( '3 Real SpreadSheet Header "ESBM";' ),
        paste( ESUBM.FOOD.i ),
        paste( ESUBM.MNFCS ),
        paste( ESUBM.SVCS ))
        writeLines(lines, con = paste('./results/sigma.', i, '.txt', sep ="") )
        system( paste('txt2har ./results/sigma.', i, '.txt ./results/sigma.', i,'.har', sep = "") )
        ## BLOCK 2.2 Run the GTAP model:
        exp <- paste('gtap -cmf tmsfse_ex2.cmf -p1=', i, sep = "")
        gtap.status <- system(exp, ignore.stdout = TRUE)
        if( gtap.status == 0){
            ## BLOCK 2.3: Extract varaiables in map to a solution file:
            ext.status <- extractvar(solution.dir = "./results/",
                                     solution.name = paste("tmsfse_ex2.",i, sep =""),
                                     var.map = "ACRS3X3_rgtap.map",
                                     solution.out = paste("./results/tmsfse_ex2.",i,".sol", sep =""))
            if( ext.status == 0){
                ## BLOCK 2.4: Read results: pm, qo, qxs(SSA, EU) and sigma:
                qo <- readsol( solution.dir = "./results/",
                              solution.out = paste("tmsfse_ex2.",i,".sol", sep =""),
                              csv.out = "qo.csv",
                              header = "0002" )
                pm <- readsol( solution.dir = "./results/",
                              solution.out = paste("tmsfse_ex2.",i,".sol", sep =""),
                              csv.out = "pm.csv",
                              header = "0001" )
                qxs <- readsol( solution.dir = "./results/",
                               solution.out = paste("tmsfse_ex2.",i,".sol", sep =""),
                               csv.out = "qxs.csv",
                               header = "0003" )
                sigma <- readsol( solution.dir = "./results/",
                                 solution.out = paste('sigma.', i, '.har', sep =""),
                                 csv.out = "sigma.csv",
                                 header = "ESBM" )
                list(qo = qo, pm = pm, qxs = qxs, sigma = sigma)
            }else{ ## Default to this if extractvar fails
                list(qo = NA, pm = NA, qxs = NA, sigma = sigma, status = ext.status)}
        }else{ ## Default to this if gtap fails
            list(qo = NA, pm = NA, qxs = NA, sigma = sigma, status = gtap.status)}
    }))
## BLOCK 3: Save results and delete unwanted files
save(mc.serial.time, mc.serial, file = "./results/ACRS3X3_ex2.RData")
file.remove(
    paste("./results/", setdiff(list.files("./results"),
                                c("ACRS3X3_ex2.RData")), sep ="")
            )
