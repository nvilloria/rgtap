## Load rgtap library:
library(rgtap)

## Run the experiment tmsfse from R:
system("gtap -cmf tmsfse.cmf")

## Extract variables defined in example1.map to a solution file named
## example1.sol:
extractvar(solution.dir = "./results/",
           solution.name = "tmsfse",
           var.map = "example1.map",
           solution.out = "./results/example1.sol")

## Read qo (%-change in output):
qo <- readsol(solution.dir = "./results/",
              solution.out = "example1.sol",
              csv.out = "./results/example1.csv",
              header = "0002")

## Plot qo (%-change in output) for the non-saving commodities in
## sub-Saharan Africa::
pdf( file = "acrs3X3qo.pdf", width = 5, height = 5 )
barplot( as.matrix( qo$Value[qo$REG == "SSA"] ), beside = T,
        names.arg = qo$NSAV_COMM[qo$REG == "SSA"],
        ylab = "% Change in Output",
        main = "Output changes in sub-Sahara Africa")
dev.off()
