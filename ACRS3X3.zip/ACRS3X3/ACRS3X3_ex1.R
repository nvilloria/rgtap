## Example 1: Plotting the changes in food output in sub-Saharan
## Africa after the EU liberalizes its markets (ACRS3X3)
## install.packages("devtools")
## Install and load rgtap library:
## library(devtools)
## install_github("nvilloria/rgtap")
library(rgtap)

## Run the experiment tmsfse from R:
a <- system("gtap -cmf tmsfse_ex1.cmf", intern = FALSE, ignore.stdout = TRUE)
#quit(save = "no", status = 0, runLast = TRUE)
## Extract variables defined in example1.map to a solution file
## named tmsfse_ex1.sol:
b <- extractvar(solution.dir = "./results/",
           solution.name = "tmsfse_ex1",
           var.map = "ACRS3X3_rgtap.map",
           solution.out = "./results/tmsfse_ex1.sol")

## Read qo (%-change in output):
qo <- readsol(solution.dir = "./results/",
              solution.out = "tmsfse_ex1.sol",
              csv.out = "./results/tmsfse_ex1.csv",
              header = "0002")

## Plot qo (%-change in output) for the non-saving commodities in
## sub-Saharan Africa::
pdf( file = "acrs3X3qo.pdf", width = 12, height = 7 )
barplot( as.matrix( qo$Value[qo$REG == "SSA"] ), beside = T,
        names.arg = qo$NSAV_COMM[qo$REG == "SSA"],
        ylab = "% Change in Output",
        main = "Output changes in sub-Saharan Africa")
dev.off()
