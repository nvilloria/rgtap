## Generate series of shocks with different degrees of correlation:

n     <- 55                    # length of vector
rho   <- 0.6                   # desired correlation = cos(angle)
x1    <- rnorm(n, 0, 1)        # fixed given data
gencorrdat <- function(n, rho, x1){
    theta <- acos(rho)             # corresponding angle
    x2    <- rnorm(n, 0, 1)      # new random data
    X     <- cbind(x1, x2)         # matrix
    Xctr  <- scale(X, center=TRUE, scale=FALSE)   # centered columns (mean 0)
    Id   <- diag(n)                               # identity matrix
    Q    <- qr.Q(qr(Xctr[ , 1, drop=FALSE]))      # QR-decomposition, just matrix Q
    P    <- tcrossprod(Q)          # = Q Q'       # projection onto space defined by x1
    x2o  <- (Id-P) %*% Xctr[ , 2]                 # x2ctr made orthogonal to x1ctr
    Xc2  <- cbind(Xctr[ , 1], x2o)                # bind to matrix
    Y    <- Xc2 %*% diag(1/sqrt(colSums(Xc2^2)))  # scale columns to length 1
    x <- Y[ , 2] + (1 / tan(theta)) * Y[ , 1]     # final new vector
    x}


.n = 100
ssa <-  rnorm(.n, 0, 1)        # fixed given data
ssa <- ssa - mean(ssa)
row <- gencorrdat(n = .n, rho = 0.21, x1 = ssa)
eu <- gencorrdat(n = .n, rho = -0.57, x1 = ssa)
.X <- cbind(ssa, eu, row)

## Correlation Matrix for text:
library(xtable)
xtable(cor(.X))
## Covariance Matrix for text:
cov(.X)
c(cov(.X))
colMeans(.X)
