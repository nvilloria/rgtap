## Example 4: Simple Statistical Analysis of Differences in Model
## Outcomes.

## BLOCK 1: Assigns parameters for MC experiments based on
## command-line arguments and uses if-else assignments to parse the
## options defined by the user:
options(echo=TRUE) ## Echoes log of MC sims to the BATCH command log
                   ## file (suffixed .Rout)
args <- commandArgs(trailingOnly = TRUE)
print(args) # Prints BATCH parameter values to log file

## Arguments are taken from the bat file, MonteCarlo.bat, which read
## this entire file:
N <- as.numeric(args[1]) ## Number of MC sims
n.cpus <- as.numeric(args[2]) ## Number of CPUs to be used
corr.shocks <- args[3] ## Correlated shocks, Y (for yes) or N(o)
policy <- args[4] ## A (for active) or I (for inactive)

## Variance-covariance matrix of hypothetical food productivity
## shocks: ssa, eu, row:

S <- matrix( c( 0.78873056, -0.06192094,  0.01917166,
               -0.06192094,  0.01496224, -0.00116997,
                0.01917166, -0.00116997,  0.01056702),
            nrow =3, ncol =3)

## Correlated Shocks:
if( corr.shocks == "Y"){
    ## If yes, the covariance matrix is used.
    .Sigma <- S
}else{
    ## Otherwise, use a square matrix with zero
    ## covariances:
    .Sigma <- diag(diag(S), nrow = 3, ncol = 3)
}

## Use variable levies to keep output constant?
if( policy == "I"){
    ## Chooses a CMF file without stabilization policy:
    cmf.file <- "tmsfse_ex4a.cmf"
}else{
    ## Chooses a CMF file that swaps qo(food,ssa) with the source
    ## generic export tax tx(food,ssa):
    cmf.file <- "tmsfse_ex4b.cmf"
}


## PARALLEL 1: SET-UP THE CLUSTER:
library(snowfall)
sfInit(parallel = TRUE, cpus = n.cpus )
sfLibrary(rgtap)
sfLibrary(MASS)
sfExport("N",".Sigma", "cmf.file")

## BLOCK 2: PARALLEL SOLUTIONS:
mc.parallel.time <- system.time(
    mc.parallel <- sfLapply(1:N, function(i){
        ## BLOCK 2.1: Draw random shocks from a multivariate normal
        ## and assign them to be passed onto gtap via the CMF:
        shocks <- mvrnorm(n =1 , mu = c(0,0,0), Sigma = .Sigma )
        ssa.ao <- shocks[1]
        eu.ao <- shocks[2]
        row.ao <- shocks[3]
        ## PARALLEL 2: SET-UP INDIVIDUAL SUB-FOLDERS
        soldir.i <- paste("./results.", i, sep = "")
        dir.create( soldir.i)
        file.copy( from = cmf.file, to = soldir.i, overwrite = TRUE)
        file.copy( from = "standard.cls", to = soldir.i, overwrite = TRUE)
        ## BLOCK 2.2 Run the GTAP model:
        exp <- paste("gtap -cmf ", paste( soldir.i, "/", cmf.file, sep = ""),
                     paste( "-p", c(1:4), "=", c(i , ssa.ao, eu.ao, row.ao),
                           sep = "", collapse = " ") )
        gtap.status <- system(exp, ignore.stdout = TRUE)
        Sys.sleep(0.1)
        if( gtap.status == 0){
        ext.status <- extractvar(solution.dir = soldir.i,
                   solution.name = paste("/tmsfse_ex4.",i, sep =""),
                   var.map = "ACRS3X3_rgtap.map",
                   solution.out = paste(soldir.i, "/tmsfse_ex4.",i,".sol", sep ="")
                   )
        Sys.sleep(0.1)
        if( ext.status == 0){
        ## BLOCK 2.4: Read results: pm, qo, qxs(SSA, EU) and sigma:
        qo <- readsol( solution.dir = soldir.i,
                      solution.out = paste("/tmsfse_ex4.",i,".sol", sep =""),
                      csv.out = paste(soldir.i, "/qo.csv", sep = ""),
                      header = "0002" )
        pm <- readsol( solution.dir = soldir.i,
                      solution.out = paste("/tmsfse_ex4.",i,".sol", sep =""),
                      csv.out = paste(soldir.i, "/pm.csv", sep = ""),
                      header = "0001" )
        qxs <- readsol( solution.dir = soldir.i,
                       solution.out = paste("/tmsfse_ex4.",i,".sol", sep =""),
                       csv.out = paste(soldir.i, "/qxs.csv", sep = ""),
                       header = "0003" )
        list(qo = qo, pm = pm, qxs = qxs, shocks = shocks, status = gtap.status)
    }else{ ## Default to this if extractvar fails
        list(qo = NA, pm = NA, qxs = NA, shocks = shocks, status = ext.status)}
    }else{ ## Default to this if gtap fails
        list(qo = NA, pm = NA, qxs = NA, shocks = shocks, status = gtap.status)}
    })
)
sfStop()
save(mc.parallel.time, mc.parallel,
     file = paste("./results/ACRS3X3_ex4.",corr.shocks,policy,
                                                 ".RData", sep = "") )
## PARALLEL 3: DELETE UNWANTED INTERMEDIATE RESULTS
unlink("results.*", recursive = TRUE)
