## Example 3: Using R for expediting Monte Carlo Analysis of
## GEMPACK-based CGE models harnessing the power of parallel
## computing:

## Load the rgtap library:
library(rgtap)

ESUBM.FOOD <- 2.39*2
ESUBM.MNFCS <- 2.86*2
ESUBM.SVCS <- 1.95*2

samples <- 100

## SET-UP THE CLUSTER:
library(snowfall)
n.cpus <- 4
sfInit(parallel = TRUE, cpus = n.cpus )

sfExport(list= list("ESUBM.FOOD", "ESUBM.MNFCS", "ESUBM.SVCS"))
sfLibrary(rgtap)

mc.parallel.time <- system.time(
    mc.parallel <- sfLapply(1:samples, function(i){
        ESUBM.FOOD.i <- rnorm(n =1, mean = ESUBM.FOOD, sd = 2)
        ##
        lines <- c(
            paste( '3 Real SpreadSheet Header "ESBD";' ),
            paste( ESUBM.FOOD.i/2),
            paste( ESUBM.MNFCS/2 ),
            paste( ESUBM.SVCS/2 ),
            paste( '3 Real SpreadSheet Header "ESBM";' ),
            paste( ESUBM.FOOD.i ),
            paste( ESUBM.MNFCS ),
            paste( ESUBM.SVCS ))
        soldir.i <- paste("./results.", i, sep = "")
        dir.create( soldir.i)
        writeLines(lines, con = paste(soldir.i, '/sigma.', i, '.txt', sep ="") )
        system( paste('txt2har ', soldir.i, '/sigma.', i, '.txt ', soldir.i, '/sigma.', i,'.har', sep = "") )
        ##
        file.copy( from = "tmsfse_ex3.cmf", to = soldir.i, overwrite = TRUE)
        file.copy( from = "standard.cls", to = soldir.i, overwrite = TRUE)
        ##
        exp <- paste('gtap -cmf ', soldir.i, '/tmsfse_ex3.cmf -p1=', i, sep = "")
        system(exp, ignore.stdout = TRUE)
        Sys.sleep(0.1)
        ## logfile <- readLines(paste(soldir.i, "/tmsfse_ex3.", i,".log", sep =""))
        ## if( length(grep("Does this simulation really have a solution?", logfile)) > 0 ){
        ## "unfeasible"}else{
        ##     if( length(grep("The program has completed without error", logfile)) > 0){
        ##         "success"}else{"crashed"}}
       ## Extract varaiables in map to a solution file:
        extractvar(solution.dir = soldir.i,
                   solution.name = paste("/tmsfsem.",i, sep =""),
                   var.map = "example1.map",
                   solution.out = paste(soldir.i, "/tmsfse_ex3.",i,".sol", sep ="")
                   )
        Sys.sleep(0.25)
        ## Read results: pm, qo, qxs(SSA, EU) and sigma:
        qo <- readsol( solution.dir = soldir.i,
                      solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                      csv.out = paste(soldir.i, "/qo.csv", sep = ""),
                      header = "0002" )
        Sys.sleep(0.25)
        pm <- readsol( solution.dir = soldir.i,
                      solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                      csv.out = paste(soldir.i, "/pm.csv", sep = ""),
                      header = "0001" )
        Sys.sleep(0.25)
        qxs <- readsol( solution.dir = soldir.i,
                       solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                       csv.out = paste(soldir.i, "/qxs.csv", sep = ""),
                       header = "0003" )
        Sys.sleep(0.25)
        sigma <- readsol( solution.dir = soldir.i,
                         solution.out = paste('/sigma.', i, '.har', sep =""),
                         csv.out = paste(soldir.i, "/sigma.csv",  sep = ""),
                         header = "ESBM" )
        Sys.sleep(0.25)
        list(qo = qo, pm = pm, qxs = qxs, sigma = sigma)
    })
)
sfStop()

##unlink(soldir.i, recursive = FALSE, force = FALSE)
save(mc.parallel.time, mc.parallel, file = "./results/mc.parallel.RData")
unlink("results.*", recursive = TRUE)
##
## load("./results/mc.parallel.RData")
## objects()
## mc.parallel.time
## summary(mc.parallel)
