## Example 3: Harnessing the power of parallel computing in R.

## Load the rgtap library:
library(rgtap)
## BLOCK 1:
ESUBM.FOOD <- 2.39*2
ESUBM.MNFCS <- 2.86*2
ESUBM.SVCS <- 1.95*2

N <- 12

## PARALLEL 1: SET-UP THE CLUSTER:
library(snowfall)
n.cpus <- 4
sfInit(parallel = TRUE, cpus = n.cpus )

sfExport(list= list("ESUBM.FOOD", "ESUBM.MNFCS", "ESUBM.SVCS"))
sfLibrary(rgtap)

## BLOCK 2: PARALLEL SOLUTIONS:
mc.parallel.time <- system.time(
    mc.parallel <- sfLapply(1:N, function(i){
        ## BLOCK 2.1: Write sigma.<p1>.har
        ESUBM.FOOD.i <- rnorm(n =1, mean = ESUBM.FOOD, sd = 2)
        lines <- c(
            paste( '3 Real SpreadSheet Header "ESBD";' ),
            paste( ESUBM.FOOD.i/2),
            paste( ESUBM.MNFCS/2 ),
            paste( ESUBM.SVCS/2 ),
            paste( '3 Real SpreadSheet Header "ESBM";' ),
            paste( ESUBM.FOOD.i ),
            paste( ESUBM.MNFCS ),
            paste( ESUBM.SVCS ))
        ## PARALLEL 2: SET-UP INDIVIDUAL SUB-FOLDERS
        soldir.i <- paste("./results.", i, sep = "")
        dir.create( soldir.i)
        writeLines(lines, con = paste(soldir.i, '/sigma.', i, '.txt', sep ="") )
        system( paste('txt2har ', soldir.i, '/sigma.', i, '.txt ', soldir.i,
                      '/sigma.', i,'.har', sep = "") )
        file.copy( from = "tmsfse_ex3.cmf", to = soldir.i, overwrite = TRUE)
        file.copy( from = "standard.cls", to = soldir.i, overwrite = TRUE)
        ## BLOCK 2.2 Run the GTAP model:
        exp <- paste('gtap -cmf ', soldir.i, '/tmsfse_ex3.cmf -p1=', i, sep = "")
        gtap.status <- system(exp, ignore.stdout = TRUE)
        Sys.sleep(0.1)
        if( gtap.status == 0){
            ## BLOCK 2.3: Extract variables in map to a solution file:
            ext.status <- extractvar(solution.dir = soldir.i,
                       solution.name = paste("/tmsfse_ex3.",i, sep =""),
                       var.map = "ACRS3X3_rgtap.map",
                       solution.out = paste(soldir.i, "/tmsfse_ex3.",i,".sol", sep ="")
                       )
            if( ext.status == 0){
            ## BLOCK 2.4: Read results: pm, qo, qxs(SSA, EU) and sigma:
            qo <- readsol( solution.dir = soldir.i,
                          solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                          csv.out = paste(soldir.i, "/qo.csv", sep = ""),
                          header = "0002" )
            pm <- readsol( solution.dir = soldir.i,
                          solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                          csv.out = paste(soldir.i, "/pm.csv", sep = ""),
                          header = "0001" )
            qxs <- readsol( solution.dir = soldir.i,
                           solution.out = paste("/tmsfse_ex3.",i,".sol", sep =""),
                           csv.out = paste(soldir.i, "/qxs.csv", sep = ""),
                           header = "0003" )
            sigma <- readsol( solution.dir = soldir.i,
                             solution.out = paste('/sigma.', i, '.har', sep =""),
                             csv.out = paste(soldir.i, "/sigma.csv",  sep = ""),
                             header = "ESBM" )
            list(qo = qo, pm = pm, qxs = qxs, sigma = sigma, status = gtap.status)
        }else{ ## Default to this if extractvar fails
            list(qo = NA, pm = NA, qxs = NA, sigma = sigma, status = ext.status)}
    }else{ ## Default to this if gtap fails
        list(qo = NA, pm = NA, qxs = NA, sigma = sigma, status = gtap.status)}
    }))
sfStop()
save(mc.parallel.time, mc.parallel, file = "./results/ACRS3X3_ex3.RData")
## PARALLEL 3: DELETE UNWANTED INTERMEDIATE RESULTS
unlink("results.*", recursive = TRUE)
