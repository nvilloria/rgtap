## Read values for plots (Change to ex3 for plot in example 3):
load("./results/ACRS3X3_ex2.RData")

## Use serial for example 2 and parallel for example 3. I.e. comment
## out "mc.serial.time" and uncomment mc.parallel.time:
mc.serial.time
## mc.parallel.time

## Use serial for example 2 and parallel for example 3:
.results <- mc.serial

status <-  sapply(.results, function(i){
    d <- i[["status"]]
})

table(status)

sigma.food <-  sapply(.results, function(i){
    d <- i[["sigma"]]
    d$Value[1]
})

qo.food.ssa <- sapply(.results, function(i){
    d <- i[["qo"]]
    with(d, d$Value[ NSAV_COMM == "Food" & REG == "SSA"] )
})

pm.food.ssa <- sapply(.results, function(i){
    d <- i[["pm"]]
    with(d, d$Value[ NSAV_COMM == "Food" & REG == "SSA"] )
})

qxs.food.ssa.eu <- sapply(.results, function(i){
    d <- i[["qxs"]]
    with(d, d$Value[ TRAD_COMM == "Food" & REG == "SSA" & REG.1 == "EU" ] )
})

## Plots:
pdf( file = "ACRS3X3ex2.pdf", width = 6, height = 6)
par( mfrow = c(2,2) )
plot( density ( sigma.food ), main = "ESUBM(FOOD)", xlab = "Trade Elasticity" )
plot( density ( qo.food.ssa ), main = "qo(FOOD, SSA)", xlab ="% change"  )
plot( density ( pm.food.ssa ), main = "pm(FOOD, SSA)", xlab ="% change"  )
plot( density ( qxs.food.ssa.eu ), main = "qxs(FOOD, SSA, EU)", xlab ="% change"  )
dev.off()
