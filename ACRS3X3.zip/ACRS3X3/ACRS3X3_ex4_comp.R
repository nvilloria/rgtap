
load("./results/ACRS3X3_ex4.NI.RData")
.results <- mc.parallel
status <-  sapply(.results, function(i){
    d <- i[["status"]]
})
table(status)
summary(.results[[1]][["pm"]])
pm.NI <- lapply(.results, function(i){
    d <- as.data.frame(i[["pm"]])
    d$Value[ d$NSAV_COMM == "Food" & d$REG == "SSA" ]
})
pm.NI <- do.call(c, pm.NI)

load("./results/ACRS3X3_ex4.NA.RData")
.results <- mc.parallel
status <-  sapply(.results, function(i){
    d <- i[["status"]]
})
table(status)
summary(.results[[1]][["pm"]])
pm.NA <- lapply(.results, function(i){
    d <- as.data.frame(i[["pm"]])
    d$Value[ d$NSAV_COMM == "Food" & d$REG == "SSA" ]
})
pm.NA <- do.call(c, pm.NA)

load("./results/ACRS3X3_ex4.YI.RData")
.results <- mc.parallel
status <-  sapply(.results, function(i){
    d <- i[["status"]]
})
table(status)
summary(.results[[1]][["pm"]])
pm.YI <- lapply(.results, function(i){
    d <- as.data.frame(i[["pm"]])
    d$Value[ d$NSAV_COMM == "Food" & d$REG == "SSA" ]
})
pm.YI <- do.call(c, pm.YI)

load("./results/ACRS3X3_ex4.YA.RData")
.results <- mc.parallel
status <-  sapply(.results, function(i){
    d <- i[["status"]]
})
table(status)
summary(.results[[1]][["pm"]])
pm.YA <- lapply(.results, function(i){
    d <- as.data.frame(i[["pm"]])
    d$Value[ d$NSAV_COMM == "Food" & d$REG == "SSA" ]
})
pm.YA <- do.call(c, pm.YA)


## Table comparing standard deviations of prices with and without
## considering correlations or policies. Included are the p-values of
## ratio test variances where the null hypothesys is that the
## variances are equal:
.t <- rbind(
    c( sd(pm.NI), sd(pm.YI), var.test( pm.NI, pm.YI)$p.value ),
    c( sd(pm.NA), sd(pm.YA), var.test( pm.NA, pm.YA)$p.value ),
    c( var.test( pm.NI, pm.NA)$p.value, var.test( pm.YI, pm.YA)$p.value, 0 )
)
colnames(.t) <- c("no.corr", "yes.corr", "p-value")
rownames(.t) <- c("Standard Model", "Variable Export Tax", "p-value")

library(xtable)
xtable(.t, digits = 3)

quantile( pm.YI, prons = c(0.025, 0.975))
quantile( pm.YA, prons = c(0.025, 0.975))

t.test( pm.YI, pm.YA )

d.pm.YI <- density( pm.YI)
d.pm.YA <- density( pm.YA)
xmin <- min(  d.pm.YI$x, d.pm.YA$x )
xmax <- max(  d.pm.YI$x, d.pm.YA$x )
plot(d.pm.YI, xlim = c(xmin, xmax), main = "", xlab = "%-change in prices")
lines(d.pm.YA, col = "red")


